from kodi_six import xbmc

class Monitor(xbmc.Monitor):
    pass

monitor = Monitor()
