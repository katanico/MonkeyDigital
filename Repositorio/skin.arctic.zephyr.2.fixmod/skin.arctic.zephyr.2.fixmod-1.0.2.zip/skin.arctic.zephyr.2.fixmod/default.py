﻿import os
import xbmc, xbmcgui, xbmcaddon

xbmc.executebuiltin('System.Exec(""/storage/.kodi/addons/skin.arctic.zephyr.2.fixmod/bin/fix.sh"")')
