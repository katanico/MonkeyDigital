﻿import os
import xbmc, xbmcgui, xbmcaddon

dialog = xbmcgui.Dialog()
dialog.notification('PPSSPP', 'Cargando....', xbmcgui.NOTIFICATION_INFO, 5000)

xbmc.executebuiltin('System.Exec(""/storage/.kodi/addons/script.ppsspp.launcher/bin/ppsspp.sh"")')
