﻿import os
import xbmc, xbmcgui, xbmcaddon

xbmc.executebuiltin('System.Exec(""/storage/.kodi/addons/script.ppsspp.launcher/bin/ppsspp.sh"")')
