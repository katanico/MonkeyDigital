import xbmcaddon
import xbmcgui
import os
import os.path
import xbmc
import time

addon = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
script_file = os.path.realpath(__file__)
directory = os.path.dirname(script_file)
adn = addon.getLocalizedString(32000)
instalar = addon.getLocalizedString(32001)
reparar = addon.getLocalizedString(32002)
vincular = addon.getLocalizedString(32003)
kipro = addon.getLocalizedString(32004)
xoro = addon.getLocalizedString(32005)
digibit = addon.getLocalizedString(32006)
picons = addon.getLocalizedString(32007)
toolbox = addon.getLocalizedString(32008)
desinstalar = addon.getLocalizedString(32009)
backup_c = addon.getLocalizedString(32010)
backup_r = addon.getLocalizedString(32011)
creditos = addon.getLocalizedString(32012)
 

dialog = xbmcgui.Dialog()
sel = dialog.select(adn, [instalar, reparar, vincular, kipro, xoro, digibit, picons, toolbox, desinstalar, backup_c, backup_r, creditos ])

if sel == 0:
    xbmc.executebuiltin("Normandy(Instalando EPG, " +  instalar.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/instalar.sh "+directory)
if sel == 1:
    xbmc.executebuiltin("Normandy(Reparando EPG, " +  reparar.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/reparar.sh "+directory)
if sel == 2:
    xbmc.executebuiltin("Normandy(Vinculando TVH+OSCAM, " +  vincular.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/vincular.sh "+directory)
if sel == 3:
    xbmc.executebuiltin("Normandy(Habilitando Tunners Ki PRO, " +  kipro.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/kipro.sh "+directory)
if sel == 4:
    xbmc.executebuiltin("Normandy(Habilitando Tunners XORO, " +  xoro.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/xoro.sh "+directory)
if sel == 5:
    xbmc.executebuiltin("Normandy(Habilitando Tunners DIGIBIT R1, " +  digibit.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/digibit.sh "+directory)
if sel == 6:
    xbmc.executebuiltin("Normandy(Reparando Picons, " +  picons.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/picons.sh "+directory)
if sel == 7:
    xbmc.executebuiltin("Normandy(Ejecutando Mecool Toolbox, " +  toolbox.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/toolbox.sh "+directory)
if sel == 8:
    xbmc.executebuiltin("Normandy(Desinstalando EPG, " +  desinstalar.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/desinstalar.sh "+directory)
if sel == 9:
    xbmc.executebuiltin("Normandy(Crear Backup TVH, " +  backup_c.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/backup_c.sh "+directory)
    
if sel == 10:
    xbmc.executebuiltin("Normandy(Restaurar Backup TVH, " +  backup_r.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/backup_r.sh "+directory)
    
if sel == 11:
    xbmc.executebuiltin("Normandy(Creditos, " +  creditos.encode('utf-8') + ")")
    time.sleep(2)
    os.system("sh "+directory+"/bin/creditos.sh "+directory)