import subprocess

subprocess.call(['./storage/.kodi/addons/script.normandy/bin/service.sh'])