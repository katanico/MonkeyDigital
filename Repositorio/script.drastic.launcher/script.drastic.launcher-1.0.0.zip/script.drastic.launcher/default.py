﻿import os
import xbmc, xbmcgui, xbmcaddon

xbmc.executebuiltin('System.Exec(""/storage/.kodi/addons/script.drastic.launcher/bin/drasti.sh"")')
