﻿import os
import xbmc, xbmcgui, xbmcaddon

dialog = xbmcgui.Dialog()
dialog.notification('Drastic', 'Cargando....', xbmcgui.NOTIFICATION_INFO, 5000)

xbmc.executebuiltin('System.Exec(""/storage/.kodi/addons/script.drastic.launcher/bin/drasti.sh"")')
