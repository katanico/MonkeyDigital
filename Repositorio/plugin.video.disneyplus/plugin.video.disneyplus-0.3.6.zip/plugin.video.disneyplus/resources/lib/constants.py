API_KEY    = 'ZGlzbmV5JmFuZHJvaWQmMS4wLjA.bkeb0m230uUhv8qrAXuNu39tbE_mD5EEhM_NAcohjyA'
CONFIG_URL = 'https://bam-sdk-configs.bamgrid.com/bam-sdk/v2.0/disney-svod-3d9324fc/android/v4.9.0/google/tv/prod.json'
PAGE_SIZE  = 50

HEADERS = {
    'User-Agent': 'BAMSDK/v4.9.0 (disney-svod-3d9324fc 1.3.0.0; v2.0/v4.9.0; android; tv)',
    'x-bamsdk-client-id': 'disney-svod-3d9324fc',
    'x-bamsdk-platform': 'android-tv',
    'x-bamsdk-version': 'v4.9.0',
    'Accept-Encoding': 'gzip',
}